import type { Formation } from '../types/formation';
import { formationsPart1 } from './formations-part1';
import { formationsPart2 } from './formations-part2';
import { formationsPart3 } from './formations-part3';
import { formationsPart4 } from './formations-part4';
import { formationsPart5 } from './formations-part5';
import { formationsPart6 } from './formations-part6';

// Agrégation de toutes les formations électriques (14 initiales + 6 recyclages = 20 total)
export const formationsElectriques: Formation[] = [
  ...formationsPart1, // B0-H0V Initial, B0-H0V CC Initial, BS Initial, BE Manœuvre Initial
  ...formationsPart2, // B1-B2-BR Initial, B1-B2-BR-BC Initial, BC Initial
  ...formationsPart3, // B1V-B2V Initial, B1V-B2V-BR Initial
  ...formationsPart4, // BP Photovoltaïque, BF-HF TST
  ...formationsPart5, // BE-HE Mesure, HE Manœuvre, etc.
  ...formationsPart6  // NOUVEAU: Recyclages B0-H0V, BS-BE, B1B2BRBC, BP, BC, B0-H0
];

// Fonction helper : récupérer une formation par slug
export function getFormationBySlug(slug: string): Formation | undefined {
  return formationsElectriques.find(f => f.slug === slug);
}

// Fonction helper : récupérer toutes les formations d'une catégorie
export function getFormationsByCategory(category: string): Formation[] {
  return formationsElectriques.filter(f => f.category === category);
}

// Fonction helper : récupérer tous les slugs (pour génération routes dynamiques)
export function getAllFormationSlugs(): string[] {
  return formationsElectriques.map(f => f.slug);
}

// Fonction helper : récupérer formation par code
export function getFormationByCode(code: string): Formation | undefined {
  return formationsElectriques.find(f => f.code === code);
}
